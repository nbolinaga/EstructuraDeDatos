package com.edd;

public class Ciudad {
    int id;
    String nombre;

    public Ciudad(int id, String nombre){
        this.id = id;
        this.nombre = nombre;
    }
}
