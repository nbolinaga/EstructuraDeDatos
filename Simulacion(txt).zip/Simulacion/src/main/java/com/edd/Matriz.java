package com.edd;

public class Matriz {
    // variables
    public int matrizDist[][];
    public double matrizFerm[][];
    private int numCiudades;
    private int numCaminos;

    // constructor
    public void Crear(Lista<Ciudad> ciudades, Lista<Camino> caminos) {
        this.numCiudades = ciudades.tamano();
        this.numCaminos = caminos.tamano();
//        establecerFeromonas(ciudades);

        // se crea una matriz de dos dimensiones donde x, y son el numero de ciudades
        matrizDist = new int [numCiudades][numCiudades];
        matrizFerm = new double[numCiudades][numCiudades];
        
        // se recorren las dos listas
        for (int i = 0; i < numCiudades; i++) {
            for(int j = 0; j < numCaminos; j++){
                // si la ciudad de origen del camino es igual a la ciudad actual se crean dos puntos en la matriz ya que los caminos son bidireccionales
                if(caminos.obtener(j).origen == i){
                    matrizDist[i][caminos.obtener(j).destino] = caminos.obtener(j).distancia;
                    matrizDist[caminos.obtener(j).destino][i] = caminos.obtener(j).distancia;
                    matrizFerm[i][caminos.obtener(j).destino] = caminos.obtener(j).cantidadFerormonas;
                    matrizFerm[caminos.obtener(j).destino][i] = caminos.obtener(j).cantidadFerormonas;
                }
            }
        }

        // se imprime la matriz con dos for loops, uno recorre x y el otro y
        for (int[] matrizDist1:  matrizDist) {
            System.out.print("\n");
            for (int j = 0; j < matrizDist.length; j++) {
                System.out.print(" | ");
                if (matrizDist1[j] == 0) {
                    System.out.print("--");
                } else {
                    System.out.format("%02d",matrizDist1[j]);
                }
            }
        }
        System.out.println("");
        
        for (double[] matrizFerm1:  matrizFerm) {
            System.out.print("\n");
            for (int j = 0; j < matrizFerm.length; j++) {
                System.out.print(" | ");
                if (matrizFerm1[j] == 0) {
                    System.out.print("----");
                } else {
                    System.out.format("%,.2f",matrizFerm1[j]);
                }
            }
        }
    }
    
    public Object[] devolver(){
        return new Object[]{matrizDist, matrizFerm};
    }
}
