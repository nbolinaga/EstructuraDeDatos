package com.edd;

public class Hormiga {
    int ciudadActual;
    int[] visitados;


    public Hormiga() {
        this.ciudadActual = 0;
    }
    
    public void calcularProbabilidad(int [][] matrizDist, double [][] matrizFer, int alpha, int beta){
        int largo = matrizDist.length;
        visitados = new int[largo];
        int[] distancias = new int[largo];
        double[] ferormonas = new double[largo];
        double [] probabilidades = new double[largo];
        double divisor;
        double dividendo;
        
        for(int i = 0; i < largo; i++){
            int ciudad = (int) matrizDist[ciudadActual][i];
            double camino = (double) matrizFer[ciudadActual][i];
            if(matrizDist[ciudadActual][i] == 0 || contiene(visitados, ciudad)){
                distancias[i] = 0;
                ferormonas[i] = 0;
            } else {
                distancias[i] = ciudad;
                ferormonas[i] = camino;
            }    
        }
        for(int i = 0; i < distancias.length; i++){
            dividendo = 0;
            if(distancias[i] == 0){
               probabilidades[i] = 0; 
            } else {
                divisor =  Math.pow((double) 1/distancias[i], alpha) * Math.pow((double) ferormonas[i], beta);
                for(int j = 0; j < distancias.length; j++){
                    if(distancias[j] == 0 || ferormonas[j] == 0){
                        divisor += 0;
                    } else {
                        dividendo += Math.pow((double) 1/distancias[j], alpha) * Math.pow((double) ferormonas[j], beta);
                    }
                }
                probabilidades[i] = divisor/dividendo; 
            }
        }
        
        elegirCamino(probabilidades);
    }   
    
    public boolean contiene(int [] visitados, int ciudad){
        for(int i = 0; i < visitados.length; i++){
            if(visitados[i] == ciudad){
                return true;
            }
        }
        return false;
    }
    
    public void elegirCamino(double[] prob){
        int largo = prob.length;
        double[] cumulative = new double[largo];
        double random = Math.random();
        
        
        // arreglar 
        cumulative[0] = 1;
        System.out.println(random);
        for(int i = 1; i < largo; i++){
          cumulative[i] = cumulative[i-1] - prob[i-1];
          cumulative[i] = redondear(cumulative[i],2);
        }
        for(int i = 0; i < largo; i++){
            System.out.println(cumulative[i]);
        }
        
        // elegir 
    }
    
    public static double redondear(double value, int places) {
        long factor = (long) Math.pow(10, places);
        value = value * factor;
        long tmp = Math.round(value);
        return (double) tmp / factor;
    }
}
