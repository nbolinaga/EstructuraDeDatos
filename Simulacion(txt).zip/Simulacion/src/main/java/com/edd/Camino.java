package com.edd;

public class Camino {
    public int origen, destino, distancia;
    public double cantidadFerormonas;

    public Camino (Ciudad origen, Ciudad destino, int distancia, int numeroCiudades){
        this.origen = origen.id;
        this.destino = destino.id;
        this.distancia = distancia;
        this.cantidadFerormonas = (double) 1/numeroCiudades;
    }
}
